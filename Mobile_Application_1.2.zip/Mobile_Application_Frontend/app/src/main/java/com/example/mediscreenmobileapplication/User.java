package com.example.mediscreenmobileapplication;

public class User {

    private boolean loggedIn;

    private String fName;
    private String lName;
    private String email;
    private String password;
    private String memberNumber;
    private String policyNumber;

    public User(String fName, String lName, String email, String password, String memberNumber, String policyNumber) {

        this.fName = fName;
        this.lName = lName;
        this.email = email;
        this.password = password;
        this.memberNumber = memberNumber;
        this.policyNumber = policyNumber;
    }

    public User(String email, String password) {

        this.email = email;
        this.password = password;

        this.fName = null;
        this.lName = null;
        this.memberNumber = null;
        this.policyNumber = null;
    }

    public User() {
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMemberNumber() {
        return memberNumber;
    }

    public void setMemberNumber(String memberNumber) {
        this.memberNumber = memberNumber;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public void setLoggedIn(Boolean loggedIn){

        this.loggedIn = loggedIn;
    }

    public Boolean getLoggedIn(){

        return this.loggedIn;
    }
}