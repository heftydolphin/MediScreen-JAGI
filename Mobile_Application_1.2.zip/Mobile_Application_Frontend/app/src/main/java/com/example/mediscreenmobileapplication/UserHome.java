package com.example.mediscreenmobileapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class UserHome extends AppCompatActivity {

    Button accountDetailsButton;
    Button addGPButton;
    Button addInsurerButton;
    Button medicalHistoryButton;
    Button paymentButton;
    Button contactButton;
    Button reviewButton;
    Button supportButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);

        accountDetailsButton = (Button) findViewById(R.id.accountDetailsButton);
        addGPButton = (Button) findViewById(R.id.addGPButton);
        addInsurerButton = (Button) findViewById(R.id.addInsurerButton);
        medicalHistoryButton = (Button) findViewById(R.id.medicalHistoryButton);
        paymentButton = (Button) findViewById(R.id.paymentButton);
        contactButton = (Button) findViewById(R.id.contactButton);
        reviewButton = (Button) findViewById(R.id.reviewButton);
        supportButton = (Button) findViewById(R.id.supportButton);

        accountDetailsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent UserDetailsActivity = new Intent(getApplicationContext(), UserDetails.class);
                startActivity(UserDetailsActivity);
            }
        });
        addGPButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        addInsurerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        medicalHistoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        paymentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        contactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        reviewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        supportButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });


    }
}
