<?php
	
	$username = $_POST['username'];	
	$fName = $_POST['fNameInput'];
	$lName = $_POST['lNameInput'];
	$practice_address1 = $_POST['addressInput1'];
	$practice_address2 = $_POST['addressInput2'];
	$practice_address3 = $_POST['addressInput3'];
	$telNo = $_POST['telNoInput'];
	$email = $_POST['emailInput'];
	$password = $_POST['passwordInput'];
	
	$HOST = "localhost";
	$DB_USERNAME = "root";
	$DB_PASSWORD = "";
	$DB_NAME = "mediscreen";
	
	$conn = new mysqli($HOST, $DB_USERNAME, $DB_PASSWORD, $DB_NAME);

	if(mysqli_connect_error()){
		die('Connect Error('.mysqli_connect_error().')'. mysqli_connect_error());
	}
	elseif(empty($username) || empty($fName) || empty($lName) || empty($telNo) || empty($email) || empty($password)){
		$errorEmpty = "You didn't fill in all fields!";
		header("Location: ../html/registerPage.html?register=emptyFields");		
		//include '../html/registerPage.html';
		exit();
		
	}
    elseif(mysqli_num_rows($result_insurer) > 0){
      while ($row = mysqli_fetch_array($result_insurer)){
        $username = $row['username'];
		$email = $row['email'];
		
      }
		$gpUserExists = "User already Exist!!";
		header("Location: ../html/registerPage.html?register=Gpinvaliduser");		
		//include '../html/registerPage.html';
		exit();
    }
	else{
		$insert = $conn->prepare("INSERT INTO gp(username, fName, lName, practiceAddress1,
								practiceAddress2, practiceAddress3, telNo,
								email, password) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)");
			
		$insert->bind_param("ssssssiss", $username, $fName, $lName, $practice_address1,
							$practice_address2, $practice_address3, 
							$telNo, $email, $password);
		$insert->execute();
		$insert->close();
		$conn->close();
	}
	include '../html/userHomePage.html';
?>