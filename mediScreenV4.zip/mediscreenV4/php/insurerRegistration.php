<?php

	$username = $_POST['username'];
	$fName = $_POST['fNameInput'];
	$lName = $_POST['lNameInput'];
	$telNo = $_POST['telNoInput'];
	$email = $_POST['emailInput'];
	$password = $_POST['passwordInput'];
	/*
	if(empty($username) || empty($fName) || empty($lName) || empty($telNo) || empty($email) || empty($password)){
		header("Location: ../html/loginPage.html?register=empty");
		exit();
	}else{
		if(!preg_match("/^[a-zA-Z]*$/", $fName) || !preg_match("/^[a-zA-Z]*$/", $lName)){
			header("Location: ../html/loginPage.html?register=char");
			exit();
		}else{
			if(!filter_var($email, FILTER_VALIDATE_EMAIL )){
				header("Location: ../html/loginPage.html?register=invalidemail");
				exit();
			}
			else{
				header("Location: ../loginPage.html?register=success");
				exit();
			}
		}
	}*/

	
	$HOST = "localhost";
	$DB_USERNAME = "root";
	$DB_PASSWORD = "";
	$DB_NAME = "mediscreen";
	
	$conn = new mysqli($HOST, $DB_USERNAME, $DB_PASSWORD, $DB_NAME);
	
    // Query MySQL search query
    $query_insurer = "SELECT * FROM insurer WHERE username = '$username' && email = '$email'";    
    $result_insurer = mysqli_query($conn, $query_insurer);

	
	if(mysqli_connect_error()){
		
		die('Connect Error('.mysqli_connect_error().')'. mysqli_connect_error());
	}
	elseif(empty($username) || empty($fName) || empty($lName) || empty($telNo) || empty($email) || empty($password)){
		$emptyError = "You didn't fill in all fields!";
		header("Location: ../html/registerPage.html?register=empty");
		//include '../html/registerPage.html';
		exit();
		
	}
    elseif(mysqli_num_rows($result_insurer) > 0){
      while ($row = mysqli_fetch_array($result_insurer)){
        $username = $row['username'];
		$email = $row['email'];
		
      }
		$InsUserExists = "User already Exist!!";
		header("Location: ../html/registerPage.html?register=invaliduser");		
		//include '../html/registerPage.html';
		exit();
    }
	else{
		$insert = $conn->prepare("INSERT INTO insurer(username, fName, lName, telNo, email, password)
			values(?, ?, ?, ?, ?, ?)");
			
		$insert->bind_param("sssiss", $username, $fName, $lName, $telNo, $email, $password);
		$insert->execute();
		$insert->close();
		$conn->close();
	}
	include '../html/userHomePage.html';
?>