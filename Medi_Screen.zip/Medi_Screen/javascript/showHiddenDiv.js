function showGPDiv(){
   document.getElementById('insurerForm').style.display = "block";
}

function show(aval) {
    
	if (aval == "gp") {
		
    insurerForm.style.display='block';
    Form.fileURL.focus();
    } 
    
	else if (aval == "insurer"){
    gpForm.style.display='block';
    Form.fileURL.focus();    
	}
	
	else{
		gpForm.style.display='none';
		insurerForm.style.display='none';
	}
}