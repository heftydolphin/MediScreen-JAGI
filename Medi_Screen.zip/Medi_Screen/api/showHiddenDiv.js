<?php

	$profession = $_POST['profession'];
	$gpForm = $_POST['gpForm'];
	
	
	$(function () {
	
		$("#profession").change(function() {
			
			var val = $(this).val();
				
				if(val === "gp") {
				
					$("#gpForm").show();
					$("#insurerForm").hide();
				}
				else if(val === "insurer") {
				
					$("#insurerForm").show();
					$("#gpForm").hide();
				}
		});
	});
?>

