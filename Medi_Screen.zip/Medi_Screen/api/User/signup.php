<?php
 
// get database connection
include_once '../config/database.php';
 
// instantiate user object
include_once '../objects/user.php';
 
$database = new Database();
$db = $database->getConnection();
 
$user = new User($db);
 
// set user property values
$user->userTitle = $_POST['userTitle']
$user->userFname = $_POST['userFname']
$user->userSname = $_POST['userSname']
$user->userProfession = $_POST['userProfession']
$user->userDOB = $_POST['userDOB']
$user->userAddress1 = $_POST['userAddres1']
$user->userAddres2 = $_POST['userAddres2']
$user->userCountry = $_POST['userCountry'];
$user->userPostcode = $_POST['userPostcode']
$user->userPhonenum = $_POST['userPhonenum']
$user->userTelenum = $_POST['userTelenum']
$user->userEmail = $_POST['userEmail']
$user->password = base64_encode($_POST['password']);
$user->created = date('Y-m-d H:i:s');
 
// create the user
if($user->signup()){
    $user_arr=array(
        "status" => true,
        "message" => "Successfully Signup!",
        "id" => $user->id,
        "userEmail" => $user->userEmail
    );
}
else{
    $user_arr=array(
        "status" => false,
        "message" => "Username already exists!"
    );
}
print_r(json_encode($user_arr));
?>