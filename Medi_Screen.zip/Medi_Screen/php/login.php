<?php

	$email = $_POST['email'];
	$password = $_POST['password'];
	
	$HOST = "localhost";
	$DB_USERNAME = "root";
	$DB_PASSWORD = "";
	$DB_NAME = "mediscreendb";
	
	$conn = new mysqli($HOST, $DB_USERNAME, $DB_PASSWORD, $DB_NAME);
	
	if(mysqli_connect_error()){
		
		die('Connect Error('.mysqli_connect_error().')'. mysqli_connect_error());
	}
	else{
		
		// Search for a user with entered email
		$select = $conn->prepare("SELECT * FROM user WHERE email = $email");
		$execute->execute();
		echo "$select;
		$insert->close();
		$conn->close();
		
	}
?>